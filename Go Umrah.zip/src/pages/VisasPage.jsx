import React, { useState } from 'react';
import GenericPage from './GenericPage';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { FileText, CheckCircle, Clock, Globe, User, Mail, Flag, FileUp, Send, Users2, Briefcase, GraduationCap, Camera } from 'lucide-react';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';
import { useApp } from '@/context/AppContext';
import { visaService } from '@/services/supabaseService';
import { useSupabaseMutation } from '@/hooks/useSupabase';

const VisaApplicationForm = ({ t, currentLang, onSuccess }) => {
  const { toast } = useToast();
  const { user } = useApp();
  const { mutate, loading } = useSupabaseMutation();
  const [formData, setFormData] = useState({
    full_name: '',
    passport_number: '',
    nationality: '',
    arrival_date: '',
    departure_date: '',
    passport_copy_url: '',
    photo_url: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!user) {
      toast({
        title: currentLang === 'ar' ? 'خطأ' : 'Error',
        description: currentLang === 'ar' ? 'يجب تسجيل الدخول أولاً' : 'Please login first',
        variant: 'destructive',
      });
      return;
    }

    try {
      await mutate(() => visaService.create({
        ...formData,
        user_id: user.id
      }));
      
      toast({
        title: currentLang === 'ar' ? 'تم إرسال الطلب' : 'Application Submitted',
        description: currentLang === 'ar' ? 'شكراً لك. سنتواصل معك قريباً لمتابعة طلبك.' : 'Thank you. We will contact you soon to follow up on your request.',
      });
      
      setFormData({
        full_name: '',
        passport_number: '',
        nationality: '',
        arrival_date: '',
        departure_date: '',
        passport_copy_url: '',
        photo_url: ''
      });
      
      if (onSuccess) onSuccess();
    } catch (error) {
      toast({
        title: currentLang === 'ar' ? 'خطأ' : 'Error',
        description: error.message,
        variant: 'destructive',
      });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="fullName">{currentLang === 'ar' ? 'الاسم الكامل' : 'Full Name'}</Label>
          <Input 
            id="fullName" 
            placeholder={currentLang === 'ar' ? 'كما في جواز السفر' : 'As in passport'} 
            value={formData.full_name}
            onChange={(e) => setFormData({...formData, full_name: e.target.value})}
            required 
          />
        </div>
        <div>
          <Label htmlFor="passportNumber">{currentLang === 'ar' ? 'رقم جواز السفر' : 'Passport Number'}</Label>
          <Input 
            id="passportNumber" 
            placeholder="A12345678" 
            value={formData.passport_number}
            onChange={(e) => setFormData({...formData, passport_number: e.target.value})}
            required 
          />
        </div>
      </div>
      <div>
        <Label htmlFor="nationality">{currentLang === 'ar' ? 'الجنسية' : 'Nationality'}</Label>
        <Input 
          id="nationality" 
          placeholder={currentLang === 'ar' ? 'مثال: مصري' : 'e.g. Egyptian'} 
          value={formData.nationality}
          onChange={(e) => setFormData({...formData, nationality: e.target.value})}
          required 
        />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="arrivalDate">{currentLang === 'ar' ? 'تاريخ الوصول المتوقع' : 'Expected Arrival Date'}</Label>
          <Input 
            id="arrivalDate" 
            type="date"
            value={formData.arrival_date}
            onChange={(e) => setFormData({...formData, arrival_date: e.target.value})}
            required 
          />
        </div>
        <div>
          <Label htmlFor="departureDate">{currentLang === 'ar' ? 'تاريخ المغادرة المتوقع' : 'Expected Departure Date'}</Label>
          <Input 
            id="departureDate" 
            type="date"
            value={formData.departure_date}
            onChange={(e) => setFormData({...formData, departure_date: e.target.value})}
            required 
          />
        </div>
      </div>
      <div>
        <Label htmlFor="passportCopy">{currentLang === 'ar' ? 'نسخة من جواز السفر' : 'Passport Copy'}</Label>
        <div className="flex items-center justify-center w-full">
            <label htmlFor="dropzone-file" className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <FileUp className="w-8 h-8 mb-4 text-gray-500" />
                    <p className="mb-2 text-sm text-gray-500">
                      <span className="font-semibold">{currentLang === 'ar' ? 'انقر للتحميل' : 'Click to upload'}</span> {currentLang === 'ar' ? 'أو اسحب وأفلت' : 'or drag and drop'}
                    </p>
                    <p className="text-xs text-gray-500">PDF, PNG, JPG (MAX. 5MB)</p>
                </div>
                <Input id="dropzone-file" type="file" className="hidden" />
            </label>
        </div> 
      </div>
      <div>
        <Label htmlFor="personalPhoto">{currentLang === 'ar' ? 'الصورة الشخصية' : 'Personal Photo'}</Label>
        <div className="flex items-center justify-center w-full">
            <label htmlFor="photo-upload" className="flex flex-col items-center justify-center w-full h-32 border-2 border-blue-300 border-dashed rounded-lg cursor-pointer bg-blue-50 hover:bg-blue-100">
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <Camera className="w-8 h-8 mb-4 text-blue-500" />
                    <p className="mb-2 text-sm text-blue-600">
                      <span className="font-semibold">{currentLang === 'ar' ? 'ارفع صورتك الشخصية' : 'Upload your personal photo'}</span>
                    </p>
                    <p className="text-xs text-blue-500">{currentLang === 'ar' ? 'صورة حديثة بخلفية بيضاء' : 'Recent photo with white background'}</p>
                    <p className="text-xs text-blue-500">PNG, JPG (MAX. 2MB)</p>
                </div>
                <Input id="photo-upload" type="file" accept="image/*" className="hidden" />
            </label>
        </div> 
      </div>
      <DialogFooter>
        <Button type="submit" className="w-full" disabled={loading}>
          <Send className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4" />
          {loading ? (currentLang === 'ar' ? 'جاري الإرسال...' : 'Submitting...') : (currentLang === 'ar' ? 'إرسال الطلب' : 'Submit Request')}
        </Button>
      </DialogFooter>
    </form>
  );
};

const VisasPage = ({ t, handleFeatureClick, currentLang }) => {
  const pageTitle = t.nav.visas;
  const pageDescription = t.services.visas.description;
  const backgroundImage = currentLang === 'ar' ? "جواز سفر مع تأشيرة سعودية" : "Passport with Saudi Arabia visa";
  const [selectedVisa, setSelectedVisa] = useState(null);

  const visaTypes = [
    {
      icon: User,
      title: currentLang === 'ar' ? 'تأشيرة سياحية' : 'Tourist Visa',
      description: currentLang === 'ar' ? 'استكشف جمال المملكة العربية السعودية وتاريخها العريق.' : 'Explore the beauty and rich history of Saudi Arabia.',
      processingTime: currentLang === 'ar' ? '24-72 ساعة' : '24-72 hours',
      validity: currentLang === 'ar' ? 'سنة واحدة، دخول متعدد' : '1 year, multiple entry',
      requirements: [ 
        currentLang === 'ar' ? 'جواز سفر ساري المفعول' : 'Valid passport', 
        currentLang === 'ar' ? 'صورة شخصية حديثة' : 'Recent photograph', 
        currentLang === 'ar' ? 'تأمين طبي' : 'Medical insurance' 
      ],
    },
    {
      icon: FileText,
      title: currentLang === 'ar' ? 'تأشيرة عمرة' : 'Umrah Visa',
      description: currentLang === 'ar' ? 'أدّ مناسك العمرة بكل يسر وسهولة مع تأشيرة مخصصة.' : 'Perform Umrah rituals with ease and convenience with a dedicated visa.',
      processingTime: currentLang === 'ar' ? 'أقل من 24 ساعة' : 'Under 24 hours',
      validity: currentLang === 'ar' ? '90 يومًا' : '90 days',
      requirements: [ 
        currentLang === 'ar' ? 'جواز سفر ساري المفعول' : 'Valid passport', 
        currentLang === 'ar' ? 'شهادة تطعيم' : 'Vaccination certificate', 
        currentLang === 'ar' ? 'حجز طيران وفندق مؤكد' : 'Confirmed flight and hotel booking' 
      ],
    },
    {
      icon: Globe,
      title: currentLang === 'ar' ? 'تأشيرة زيارة عمل' : 'Business Visit Visa',
      description: currentLang === 'ar' ? 'لحضور الاجتماعات والمؤتمرات وتوسيع أعمالك في المملكة.' : 'For attending meetings, conferences, and expanding your business in the Kingdom.',
      processingTime: currentLang === 'ar' ? '3-5 أيام عمل' : '3-5 business days',
      validity: currentLang === 'ar' ? 'تعتمد على الدعوة' : 'Depends on invitation',
      requirements: [ 
        currentLang === 'ar' ? 'خطاب دعوة من شركة سعودية' : 'Invitation letter from a Saudi company', 
        currentLang === 'ar' ? 'سجل تجاري للشركة الداعية' : 'Commercial registration of the inviting company' 
      ],
    },
    {
      icon: Users2,
      title: currentLang === 'ar' ? 'تأشيرة زيارة عائلية' : 'Family Visit Visa',
      description: currentLang === 'ar' ? 'لزيارة أفراد عائلتك المقيمين في المملكة العربية السعودية.' : 'To visit your family members residing in Saudi Arabia.',
      processingTime: currentLang === 'ar' ? '5-7 أيام عمل' : '5-7 business days',
      validity: currentLang === 'ar' ? '90 يومًا، قابلة للتمديد' : '90 days, extendable',
      requirements: [ 
        currentLang === 'ar' ? 'إثبات صلة القرابة' : 'Proof of relationship', 
        currentLang === 'ar' ? 'دعوة من فرد العائلة المقيم' : 'Invitation from the resident family member' 
      ],
    },
    {
      icon: Briefcase,
      title: currentLang === 'ar' ? 'تأشيرة عمل' : 'Work Visa',
      description: currentLang === 'ar' ? 'للأفراد الذين حصلوا على عروض عمل من شركات سعودية.' : 'For individuals who have received job offers from Saudi companies.',
      processingTime: currentLang === 'ar' ? '1-3 أسابيع' : '1-3 weeks',
      validity: currentLang === 'ar' ? 'حسب مدة العقد' : 'Based on contract duration',
      requirements: [ 
        currentLang === 'ar' ? 'عقد عمل مصدق' : 'Attested employment contract', 
        currentLang === 'ar' ? 'مؤهلات علمية وعملية' : 'Educational and professional qualifications' 
      ],
    },
    {
      icon: GraduationCap,
      title: currentLang === 'ar' ? 'تأشيرة طالب' : 'Student Visa',
      description: currentLang === 'ar' ? 'للطلاب المقبولين في المؤسسات التعليمية السعودية.' : 'For students accepted into Saudi educational institutions.',
      processingTime: currentLang === 'ar' ? '2-4 أسابيع' : '2-4 weeks',
      validity: currentLang === 'ar' ? 'طوال فترة الدراسة' : 'Duration of study',
      requirements: [ 
        currentLang === 'ar' ? 'خطاب قبول من الجامعة' : 'Admission letter from the university', 
        currentLang === 'ar' ? 'شهادة خلو من السوابق' : 'Police clearance certificate' 
      ],
    },
  ];

  return (
    <GenericPage pageKey="visas" pageTitle={pageTitle} pageDescription={pageDescription} t={t} currentLang={currentLang} backgroundImage={backgroundImage}>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {visaTypes.map((visa, index) => (
          <motion.div
            key={visa.title}
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-lg overflow-hidden border border-gray-200/50 flex flex-col"
          >
            <div className="p-6">
              <div className="flex items-center mb-4">
                <div className="p-3 bg-primary/10 rounded-full mr-4 rtl:ml-4 rtl:mr-0">
                  <visa.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className={`text-xl font-bold text-primary ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                  {visa.title}
                </h3>
              </div>
              <p className={`text-gray-600 mb-4 text-sm ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                {visa.description}
              </p>
              
              <div className="space-y-2 text-sm mb-4">
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0 text-secondary" />
                  <span>{currentLang === 'ar' ? 'مدة الإنجاز: ' : 'Processing Time: '}{visa.processingTime}</span>
                </div>
                <div className="flex items-center">
                  <FileText className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0 text-secondary" />
                  <span>{currentLang === 'ar' ? 'الصلاحية: ' : 'Validity: '}{visa.validity}</span>
                </div>
              </div>

              <h4 className={`font-semibold mb-2 ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                {currentLang === 'ar' ? 'أهم المتطلبات:' : 'Key Requirements:'}
              </h4>
              <ul className="space-y-1 list-inside">
                {visa.requirements.map((req, i) => (
                  <li key={i} className="flex items-start text-sm text-gray-700">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2 rtl:ml-2 rtl:mr-0 mt-0.5 flex-shrink-0" />
                    <span>{req}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="mt-auto p-6 bg-gray-50">
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="w-full" onClick={() => setSelectedVisa(visa)}>
                    {currentLang === 'ar' ? 'اطلب الآن' : 'Apply Now'}
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px]">
                  <DialogHeader>
                    <DialogTitle className={`${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                      {currentLang === 'ar' ? `طلب ${visa.title}` : `Apply for ${visa.title}`}
                    </DialogTitle>
                    <DialogDescription className={`${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                      {currentLang === 'ar' ? 'يرجى ملء النموذج أدناه وسنتواصل معك.' : 'Please fill out the form below and we will contact you.'}
                    </DialogDescription>
                  </DialogHeader>
                  <VisaApplicationForm t={t} currentLang={currentLang} />
                </DialogContent>
              </Dialog>
            </div>
          </motion.div>
        ))}
      </div>
    </GenericPage>
  );
};

export default VisasPage;