
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import GenericPage from './GenericPage';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Filter, Star, CalendarDays, Users, DollarSign, MapPin, Plane, CheckSquare, Building, Globe2, Sun, Moon, UserCheck, ShieldCheck, Car, Utensils, Briefcase, ChevronLeft, ChevronRight, Home, PlaneTakeoff } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useUmrahPackages } from '@/hooks/useSupabase';
import { useToast } from '@/components/ui/use-toast';

const PackagesView = ({ t, currentLang, handleFeatureClick, handleBookNow, packages, category, loading }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState({ priceRange: 'all', duration: 'all', hotelRating: 'all' });
  const packagesPerPage = 6;

  const totalPages = Math.ceil(packages.length / packagesPerPage);
  const startIndex = (currentPage - 1) * packagesPerPage;
  const currentPagePackages = packages.slice(startIndex, startIndex + packagesPerPage);

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col lg:flex-row gap-8">
      <div className="lg:w-1/4">
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl p-6 border border-gray-200/50 sticky top-24">
          <h3 className={`text-xl font-bold text-primary mb-4 flex items-center ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
            <Filter className="h-5 w-5 mr-2 rtl:ml-2" />
            {currentLang === 'ar' ? 'الفلاتر' : 'Filters'}
          </h3>
          <div className="space-y-4">
            <div>
              <Label className={`block text-sm font-medium text-gray-700 mb-2 ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                {currentLang === 'ar' ? 'نطاق السعر' : 'Price Range'}
              </Label>
              <Select value={filters.priceRange} onValueChange={(value) => setFilters({...filters, priceRange: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{currentLang === 'ar' ? 'جميع الأسعار' : 'All Prices'}</SelectItem>
                  <SelectItem value="budget">{currentLang === 'ar' ? 'اقتصادي' : 'Budget'}</SelectItem>
                  <SelectItem value="mid">{currentLang === 'ar' ? 'متوسط' : 'Mid-range'}</SelectItem>
                  <SelectItem value="luxury">{currentLang === 'ar' ? 'فاخر' : 'Luxury'}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className={`block text-sm font-medium text-gray-700 mb-2 ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                {currentLang === 'ar' ? 'المدة' : 'Duration'}
              </Label>
              <Select value={filters.duration} onValueChange={(value) => setFilters({...filters, duration: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{currentLang === 'ar' ? 'جميع المدد' : 'All Durations'}</SelectItem>
                  <SelectItem value="short">{currentLang === 'ar' ? 'قصيرة (3-5 أيام)' : 'Short (3-5 days)'}</SelectItem>
                  <SelectItem value="medium">{currentLang === 'ar' ? 'متوسطة (6-10 أيام)' : 'Medium (6-10 days)'}</SelectItem>
                  <SelectItem value="long">{currentLang === 'ar' ? 'طويلة (أكثر من 10 أيام)' : 'Long (10+ days)'}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className={`block text-sm font-medium text-gray-700 mb-2 ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                {currentLang === 'ar' ? 'تصنيف الفندق' : 'Hotel Rating'}
              </Label>
              <Select value={filters.hotelRating} onValueChange={(value) => setFilters({...filters, hotelRating: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{currentLang === 'ar' ? 'جميع التصنيفات' : 'All Ratings'}</SelectItem>
                  <SelectItem value="3">3 {currentLang === 'ar' ? 'نجوم' : 'Stars'}</SelectItem>
                  <SelectItem value="4">4 {currentLang === 'ar' ? 'نجوم' : 'Stars'}</SelectItem>
                  <SelectItem value="5">5 {currentLang === 'ar' ? 'نجوم' : 'Stars'}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button className="w-full" onClick={() => handleFeatureClick(currentLang === 'ar' ? 'تطبيق الفلاتر' : 'Apply Filters')}>
              {currentLang === 'ar' ? 'تطبيق الفلاتر' : 'Apply Filters'}
            </Button>
          </div>
        </div>
      </div>
      <div className="lg:w-3/4">
        {currentPagePackages.length === 0 ? (
          <div className="text-center py-12">
            <p className={`text-gray-500 ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
              {currentLang === 'ar' ? 'لا توجد باقات متاحة حالياً' : 'No packages available at the moment'}
            </p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {currentPagePackages.map((pkg) => (
                <motion.div 
                  key={pkg.id} 
                  initial={{ opacity: 0, scale: 0.9 }} 
                  animate={{ opacity: 1, scale: 1 }} 
                  transition={{ duration: 0.3 }} 
                  className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200 hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
                >
                  <div className="relative h-48">
                    <img 
                      src="https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa" 
                      alt={pkg.title} 
                      className="w-full h-full object-cover" 
                    />
                    <div className="absolute top-4 right-4">
                      <div className="bg-primary text-white px-3 py-1 rounded-full text-sm font-semibold">
                        {pkg.price} {currentLang === 'ar' ? 'ريال' : 'SAR'}
                      </div>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className={`text-lg font-bold text-gray-900 mb-2 line-clamp-2 ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                      {pkg.title}
                    </h3>
                    <div className="space-y-2 mb-4">
                      <div className="flex items-center text-sm text-gray-600">
                        <CalendarDays className="h-4 w-4 mr-2 rtl:ml-2 text-primary" />
                        <span className={currentLang === 'ar' ? 'font-arabic' : 'font-english'}>
                          {pkg.duration_days} {currentLang === 'ar' ? 'أيام' : 'days'}
                        </span>
                      </div>
                      {pkg.city && (
                        <div className="flex items-center text-sm text-gray-600">
                          <MapPin className="h-4 w-4 mr-2 rtl:ml-2 text-primary" />
                          <span className={currentLang === 'ar' ? 'font-arabic' : 'font-english'}>{pkg.city}</span>
                        </div>
                      )}
                      {pkg.hotel_rating && (
                        <div className="flex items-center text-sm text-gray-600">
                          <Building className="h-4 w-4 mr-2 rtl:ml-2 text-primary" />
                          <span className={`line-clamp-1 ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                            {pkg.hotel_rating} {currentLang === 'ar' ? 'نجوم' : 'Stars'}
                          </span>
                        </div>
                      )}
                      {pkg.service_providers && (
                        <div className="flex items-center text-sm text-gray-600">
                          <Briefcase className="h-4 w-4 mr-2 rtl:ml-2 text-primary" />
                          <span className={`line-clamp-1 ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                            {pkg.service_providers.company_name}
                          </span>
                        </div>
                      )}
                    </div>
                    
                    {pkg.includes && (
                      <div className="flex flex-wrap gap-1 mb-4">
                        {pkg.includes.slice(0, 3).map((item, index) => (
                          <span key={index} className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                            <CheckSquare className="h-3 w-3 mr-1 rtl:ml-1" />
                            {item}
                          </span>
                        ))}
                        {pkg.includes.length > 3 && (
                          <span className="text-xs text-gray-500">
                            +{pkg.includes.length - 3} {currentLang === 'ar' ? 'المزيد' : 'more'}
                          </span>
                        )}
                      </div>
                    )}
                    
                    <div className="flex gap-2">
                      <Button size="sm" className="flex-1" onClick={() => handleBookNow(pkg)}>
                        {(t.buttons?.bookNow) || (currentLang === 'ar' ? 'احجز الآن' : 'Book Now')}
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1" onClick={() => handleFeatureClick(currentLang === 'ar' ? 'عرض التفاصيل' : 'View Details')}>
                        {(t.buttons?.viewDetails) || (currentLang === 'ar' ? 'التفاصيل' : 'Details')}
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
            {totalPages > 1 && (
              <div className="flex justify-center items-center mt-8 space-x-2 rtl:space-x-reverse">
                <Button variant="outline" size="sm" onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))} disabled={currentPage === 1}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                  <Button 
                    key={page} 
                    variant={currentPage === page ? "default" : "outline"} 
                    size="sm" 
                    onClick={() => setCurrentPage(page)} 
                    className="min-w-[40px]"
                  >
                    {page}
                  </Button>
                ))}
                <Button variant="outline" size="sm" onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))} disabled={currentPage === totalPages}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

const CategorySelector = ({ onSelect, t, currentLang }) => (
  <div className="flex flex-col items-center justify-center py-12 space-y-8">
    <h2 className={`text-3xl font-bold text-center text-primary ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
      {currentLang === 'ar' ? 'اختر فئة المعتمرين' : 'Select Pilgrim Category'}
    </h2>
    <div className="grid md:grid-cols-2 gap-8 w-full max-w-4xl">
      <motion.div 
        whileHover={{ scale: 1.03, boxShadow: "0px 10px 30px rgba(0,0,0,0.1)" }} 
        className="bg-white/90 backdrop-blur-sm p-8 rounded-2xl shadow-lg cursor-pointer text-center border border-gray-200/50" 
        onClick={() => onSelect('domestic')}
      >
        <Home className="h-16 w-16 mx-auto text-primary mb-4" />
        <h3 className={`text-2xl font-bold text-primary mb-2 ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
          {t.services.umrah.types.domestic}
        </h3>
        <p className={`text-gray-600 ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
          {currentLang === 'ar' ? 'باقات مصممة للمواطنين والمقيمين داخل المملكة.' : 'Packages designed for citizens and residents within the Kingdom.'}
        </p>
      </motion.div>
      <motion.div 
        whileHover={{ scale: 1.03, boxShadow: "0px 10px 30px rgba(0,0,0,0.1)" }} 
        className="bg-white/90 backdrop-blur-sm p-8 rounded-2xl shadow-lg cursor-pointer text-center border border-gray-200/50" 
        onClick={() => onSelect('international')}
      >
        <PlaneTakeoff className="h-16 w-16 mx-auto text-primary mb-4" />
        <h3 className={`text-2xl font-bold text-primary mb-2 ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
          {t.services.umrah.types.international}
        </h3>
        <p className={`text-gray-600 ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
          {currentLang === 'ar' ? 'باقات شاملة للمعتمرين القادمين من جميع أنحاء العالم.' : 'All-inclusive packages for pilgrims from around the world.'}
        </p>
      </motion.div>
    </div>
  </div>
);

const UmrahPackagesPage = ({ t, handleFeatureClick, currentLang, handleAddToCart }) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [activeCategory, setActiveCategory] = useState(null);
  
  const { data: packages, loading } = useUmrahPackages();

  const handleBookNow = (packageItem) => {
    toast({
      title: currentLang === 'ar' ? 'جاري التوجيه...' : 'Redirecting...',
      description: currentLang === 'ar' ? 'سيتم توجيهك لصفحة الحجز' : 'You will be redirected to booking page',
    });
    
    handleAddToCart(packageItem, 'umrah_package');
    navigate('/checkout');
  };

  const pageTitle = t.nav.umrahPackages;
  const pageDescription = t.services.umrah.description;

  return (
    <GenericPage pageKey="umrahPackages" pageTitle={pageTitle} pageDescription={pageDescription} t={t} currentLang={currentLang}>
      {!activeCategory ? (
        <CategorySelector onSelect={setActiveCategory} t={t} currentLang={currentLang} />
      ) : (
        <div className="space-y-8">
          <Button 
            onClick={() => setActiveCategory(null)} 
            variant="outline" 
            className={`mb-6 flex items-center gap-2 bg-white/80 hover:bg-white ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}
          >
            {currentLang === 'ar' ? <ChevronRight className="h-5 w-5" /> : <ChevronLeft className="h-5 w-5" />}
            {currentLang === 'ar' ? 'العودة لاختيار الفئة' : 'Back to Category Selection'}
          </Button>
          <PackagesView
            t={t}
            currentLang={currentLang}
            handleFeatureClick={handleFeatureClick}
            handleBookNow={handleBookNow}
            packages={packages || []}
            category={activeCategory}
            loading={loading}
          />
        </div>
      )}
    </GenericPage>
  );
};

export default UmrahPackagesPage;
