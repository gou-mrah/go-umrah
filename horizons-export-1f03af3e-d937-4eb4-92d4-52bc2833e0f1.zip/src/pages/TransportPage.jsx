import React, { useState } from 'react';
import GenericPage from './GenericPage';
import { Button } from '@/components/ui/button';
import { CarFront, Users, Luggage, Snowflake, Star, Bus, Filter, DollarSign } from 'lucide-react';
import { motion } from 'framer-motion';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const TransportPage = ({ t, handleFeatureClick, currentLang, handleAddToCart }) => {
  const pageTitle = t.nav.transport;
  const pageDescription = t.services.transport.description;
  const backgroundImage = currentLang === 'ar' ? "سيارة حديثة أمام الحرم المكي" : "Modern car in front of the Grand Mosque in Makkah";

  const allTransportPackages = [
    { id: 'sedan-1', name: currentLang === 'ar' ? 'سيارة سيدان اقتصادية' : 'Economy Sedan', type: 'Sedan', image: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d', capacity: 4, luggage: 2, price: 250, features: [{ icon: Snowflake, text: currentLang === 'ar' ? 'تكييف' : 'A/C' }] },
    { id: 'suv-1', name: currentLang === 'ar' ? 'سيارة دفع رباعي عائلية' : 'Family SUV', type: 'SUV', image: 'https://images.unsplash.com/photo-1583121274602-3e2820c69888', capacity: 7, luggage: 5, price: 450, features: [{ icon: Snowflake, text: currentLang === 'ar' ? 'تكييف' : 'A/C' }, { icon: Star, text: currentLang === 'ar' ? 'سائق محترف' : 'Pro Driver' }] },
    { id: 'van-1', name: currentLang === 'ar' ? 'فان للمجموعات الصغيرة' : 'Small Group Van', type: 'Van', image: 'https://images.unsplash.com/photo-1591492942229-8157389286c0', capacity: 9, luggage: 8, price: 600, features: [{ icon: Snowflake, text: currentLang === 'ar' ? 'تكييف' : 'A/C' }, { icon: Users, text: currentLang === 'ar' ? 'مساحة واسعة' : 'Spacious' }] },
    { id: 'bus-1', name: currentLang === 'ar' ? 'حافلة سياحية فاخرة' : 'Luxury Tourist Bus', type: 'Bus', image: 'https://images.unsplash.com/photo-1570125909232-eb263c186f2e', capacity: 50, luggage: 50, price: 1500, features: [{ icon: Snowflake, text: currentLang === 'ar' ? 'تكييف مركزي' : 'Central A/C' }, { icon: Bus, text: currentLang === 'ar' ? 'مرشد سياحي' : 'Tour Guide' }] },
    { id: 'luxury-sedan-1', name: currentLang === 'ar' ? 'مرسيدس الفئة S' : 'Mercedes S-Class', type: 'Luxury', image: 'https://images.unsplash.com/photo-1617469747579-9f249b0a0f2c', capacity: 3, luggage: 2, price: 900, features: [{ icon: Snowflake, text: currentLang === 'ar' ? 'تكييف' : 'A/C' }, { icon: Star, text: currentLang === 'ar' ? 'خدمة VIP' : 'VIP Service' }] },
    { id: 'minibus-1', name: currentLang === 'ar' ? 'ميني باص للمجموعات' : 'Group Minibus', type: 'Bus', image: 'https://images.unsplash.com/photo-1605816988069-b11383b50736', capacity: 15, luggage: 15, price: 850, features: [{ icon: Snowflake, text: currentLang === 'ar' ? 'تكييف' : 'A/C' }, { icon: Users, text: currentLang === 'ar' ? 'مريح' : 'Comfortable' }] },
  ];

  const [filters, setFilters] = useState({ type: 'all', price: 'all', capacity: 'all' });
  const vehicleTypes = ['all', ...new Set(allTransportPackages.map(p => p.type))];

  const filteredPackages = allTransportPackages.filter(p => {
    const typeMatch = filters.type === 'all' || p.type === filters.type;
    const capacityMatch = filters.capacity === 'all' || p.capacity >= parseInt(filters.capacity);
    const priceMatch = filters.price === 'all' ||
      (filters.price === 'low' && p.price <= 400) ||
      (filters.price === 'mid' && p.price > 400 && p.price <= 800) ||
      (filters.price === 'high' && p.price > 800);
    return typeMatch && capacityMatch && priceMatch;
  });

  return (
    <GenericPage pageKey="transport" pageTitle={pageTitle} pageDescription={pageDescription} t={t} currentLang={currentLang} backgroundImage={backgroundImage}>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <aside className="lg:col-span-1 bg-white/90 backdrop-blur-sm p-6 rounded-xl shadow-lg h-fit sticky top-24 border border-gray-200/50">
          <h3 className={`text-xl font-bold mb-6 flex items-center text-primary ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
            <Filter className="mr-2 rtl:ml-2 rtl:mr-0 h-5 w-5" />
            {currentLang === 'ar' ? 'تصفية الخيارات' : 'Filter Options'}
          </h3>
          <div className="space-y-5">
            <div>
              <Label className={`block text-sm font-semibold text-gray-800 mb-1.5 flex items-center ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                <CarFront className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4 text-gray-500" />
                {currentLang === 'ar' ? 'نوع المركبة' : 'Vehicle Type'}
              </Label>
              <Select value={filters.type} onValueChange={(value) => setFilters(f => ({...f, type: value}))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {vehicleTypes.map(c => <SelectItem key={c} value={c}>{c === 'all' ? (currentLang === 'ar' ? 'الكل' : 'All') : c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className={`block text-sm font-semibold text-gray-800 mb-1.5 flex items-center ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                <DollarSign className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4 text-gray-500" />
                {currentLang === 'ar' ? 'السعر' : 'Price'}
              </Label>
              <Select value={filters.price} onValueChange={(value) => setFilters(f => ({...f, price: value}))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{currentLang === 'ar' ? 'كل الأسعار' : 'All Prices'}</SelectItem>
                  <SelectItem value="low">{currentLang === 'ar' ? 'منخفض' : 'Low'}</SelectItem>
                  <SelectItem value="mid">{currentLang === 'ar' ? 'متوسط' : 'Medium'}</SelectItem>
                  <SelectItem value="high">{currentLang === 'ar' ? 'مرتفع' : 'High'}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className={`block text-sm font-semibold text-gray-800 mb-1.5 flex items-center ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                <Users className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4 text-gray-500" />
                {currentLang === 'ar' ? 'السعة' : 'Capacity'}
              </Label>
              <Select value={filters.capacity} onValueChange={(value) => setFilters(f => ({...f, capacity: value}))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{currentLang === 'ar' ? 'أي سعة' : 'Any Capacity'}</SelectItem>
                  <SelectItem value="4">{currentLang === 'ar' ? '4 ركاب فأكثر' : '4+ Passengers'}</SelectItem>
                  <SelectItem value="7">{currentLang === 'ar' ? '7 ركاب فأكثر' : '7+ Passengers'}</SelectItem>
                  <SelectItem value="15">{currentLang === 'ar' ? '15 راكب فأكثر' : '15+ Passengers'}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </aside>
        <main className="lg:col-span-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {filteredPackages.map((pkg, index) => (
              <motion.div
                key={pkg.id}
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-lg overflow-hidden border border-gray-200/50 flex flex-col"
              >
                <div className="relative">
                  <img  className="w-full h-48 object-cover" alt={pkg.name} src={pkg.image} />
                  <div className="absolute top-0 right-0 bg-primary text-white text-sm font-bold px-3 py-1 rounded-bl-lg">
                    {pkg.price} {currentLang === 'ar' ? 'ريال' : 'SAR'}
                  </div>
                </div>
                <div className="p-6 flex flex-col flex-grow">
                  <h3 className={`text-xl font-bold text-primary mb-2 ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>{pkg.name}</h3>
                  <div className="flex items-center text-gray-600 text-sm space-x-4 rtl:space-x-reverse mb-4">
                    <span className="flex items-center"><Users className="h-4 w-4 mr-1 rtl:ml-1 rtl:mr-0" /> {pkg.capacity} {currentLang === 'ar' ? 'ركاب' : 'Pax'}</span>
                    <span className="flex items-center"><Luggage className="h-4 w-4 mr-1 rtl:ml-1 rtl:mr-0" /> {pkg.luggage} {currentLang === 'ar' ? 'حقائب' : 'Bags'}</span>
                  </div>
                  <div className="space-y-2 mb-4">
                    {pkg.features.map((feature, i) => (
                      <div key={i} className="flex items-center text-sm text-gray-700">
                        <feature.icon className="h-4 w-4 text-green-500 mr-2 rtl:ml-2 rtl:mr-0" />
                        <span>{feature.text}</span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-auto">
                    <Button className="w-full" onClick={() => handleAddToCart({...pkg, price: `${pkg.price} ${currentLang === 'ar' ? 'ريال' : 'SAR'}`}, 'transport')}>
                      <CarFront className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4" />
                      {currentLang === 'ar' ? 'احجز الآن' : 'Book Now'}
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </main>
      </div>
    </GenericPage>
  );
};

export default TransportPage;