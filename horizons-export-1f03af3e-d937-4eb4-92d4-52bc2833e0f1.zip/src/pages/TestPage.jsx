import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/context/AuthContext';
import { useApp } from '@/context/AppContext';
import { 
  User, 
  Package, 
  ShoppingCart, 
  Database, 
  CheckCircle, 
  XCircle, 
  Clock,
  Plus,
  Eye,
  Edit,
  Trash2,
  Star,
  MapPin,
  Calendar,
  Users,
  Plane,
  Building,
  Train,
  Car,
  Store,
  FileText,
  MessageSquare
} from 'lucide-react';
import { 
  supabase,
  serviceProviderService,
  packageService,
  flightService,
  hotelService,
  storeService,
  orderService,
  visaService,
  complaintService
} from '@/lib/supabase';

const TestPage = ({ t, currentLang }) => {
  const { user, login, register, logout } = useAuth();
  const { cart, addToCart, services, loadingServices } = useApp();
  const { toast } = useToast();

  const [testResults, setTestResults] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [testData, setTestData] = useState({
    email: 'test@example.com',
    password: 'Test123456',
    fullName: 'مستخدم تجريبي',
    role: 'customer'
  });

  const [newPackage, setNewPackage] = useState({
    title: 'باقة عمرة تجريبية',
    description: 'باقة عمرة شاملة للاختبار',
    price: 2500,
    duration_days: 7,
    city: 'مكة المكرمة',
    hotel_rating: 4
  });

  const [newComplaint, setNewComplaint] = useState({
    full_name: 'مستخدم تجريبي',
    email: 'test@example.com',
    phone: '0501234567',
    subject: 'شكوى تجريبية',
    message: 'هذه شكوى تجريبية لاختبار النظام'
  });

  const runTest = async (testName, testFunction) => {
    setIsLoading(true);
    try {
      const result = await testFunction();
      setTestResults(prev => ({
        ...prev,
        [testName]: { success: true, message: result }
      }));
      toast({
        title: currentLang === 'ar' ? 'نجح الاختبار' : 'Test Passed',
        description: `${testName}: ${result}`,
      });
    } catch (error) {
      setTestResults(prev => ({
        ...prev,
        [testName]: { success: false, message: error.message }
      }));
      toast({
        title: currentLang === 'ar' ? 'فشل الاختبار' : 'Test Failed',
        description: `${testName}: ${error.message}`,
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const testDatabaseConnection = async () => {
    const { data, error } = await supabase.from('store_products').select('count').limit(1);
    if (error) throw error;
    return currentLang === 'ar' ? 'تم الاتصال بقاعدة البيانات بنجاح' : 'Database connection successful';
  };

  const testUserRegistration = async () => {
    try {
      await register(testData.fullName, testData.email, testData.password, testData.role);
      return currentLang === 'ar' ? 'تم تسجيل المستخدم بنجاح' : 'User registration successful';
    } catch (error) {
      if (error.message.includes('already registered')) {
        return currentLang === 'ar' ? 'المستخدم مسجل مسبقاً' : 'User already exists';
      }
      throw error;
    }
  };

  const testUserLogin = async () => {
    await login(testData.email, testData.password);
    return currentLang === 'ar' ? 'تم تسجيل الدخول بنجاح' : 'Login successful';
  };

  const testLoadServices = async () => {
    const { data: products } = await supabase.from('store_products').select('*').limit(5);
    const { data: packages } = await supabase.from('umrah_packages').select('*').limit(5);
    return currentLang === 'ar' 
      ? `تم تحميل ${products?.length || 0} منتج و ${packages?.length || 0} باقة`
      : `Loaded ${products?.length || 0} products and ${packages?.length || 0} packages`;
  };

  const testAddToCart = async () => {
    if (services.storeProducts.length > 0) {
      addToCart(services.storeProducts[0], 'store_product');
      return currentLang === 'ar' ? 'تم إضافة منتج إلى السلة' : 'Product added to cart';
    }
    throw new Error(currentLang === 'ar' ? 'لا توجد منتجات للإضافة' : 'No products to add');
  };

  const testCreateComplaint = async () => {
    if (!user) throw new Error(currentLang === 'ar' ? 'يجب تسجيل الدخول أولاً' : 'Must be logged in');
    
    const complaint = await complaintService.create({
      ...newComplaint,
      user_id: user.id
    });
    
    return currentLang === 'ar' ? 'تم إنشاء الشكوى بنجاح' : 'Complaint created successfully';
  };

  const testCreatePackage = async () => {
    if (!user) throw new Error(currentLang === 'ar' ? 'يجب تسجيل الدخول أولاً' : 'Must be logged in');
    
    const { data: providers } = await supabase
      .from('service_providers')
      .select('*')
      .eq('profile_id', user.id)
      .limit(1);

    if (!providers || providers.length === 0) {
      const provider = await serviceProviderService.create({
        profile_id: user.id,
        company_name: 'شركة تجريبية للسياحة',
        commercial_registration_number: '1234567890',
        tourism_license_number: 'TL123456',
        address: 'الرياض، المملكة العربية السعودية'
      });
      
      const packageData = await packageService.createUmrahPackage({
        ...newPackage,
        provider_id: provider.id
      });
    } else {
      const packageData = await packageService.createUmrahPackage({
        ...newPackage,
        provider_id: providers[0].id
      });
    }
    
    return currentLang === 'ar' ? 'تم إنشاء الباقة بنجاح' : 'Package created successfully';
  };

  const testOrderProcess = async () => {
    if (!user) throw new Error(currentLang === 'ar' ? 'يجب تسجيل الدخول أولاً' : 'Must be logged in');
    if (cart.length === 0) throw new Error(currentLang === 'ar' ? 'السلة فارغة' : 'Cart is empty');
    
    const orderData = {
      user_id: user.id,
      total_amount: cart.reduce((total, item) => total + (item.price * item.quantity), 0),
      status: 'pending'
    };

    const orderItems = cart.map(item => ({
      item_type: item.type,
      item_id: item.id,
      quantity: item.quantity,
      price_at_purchase: item.price
    }));

    const result = await orderService.create(orderData, orderItems);
    return currentLang === 'ar' ? 'تم إنشاء الطلب بنجاح' : 'Order created successfully';
  };

  const allTests = [
    {
      name: currentLang === 'ar' ? 'اتصال قاعدة البيانات' : 'Database Connection',
      icon: Database,
      test: () => runTest('database', testDatabaseConnection)
    },
    {
      name: currentLang === 'ar' ? 'تسجيل مستخدم جديد' : 'User Registration',
      icon: User,
      test: () => runTest('registration', testUserRegistration)
    },
    {
      name: currentLang === 'ar' ? 'تسجيل الدخول' : 'User Login',
      icon: User,
      test: () => runTest('login', testUserLogin)
    },
    {
      name: currentLang === 'ar' ? 'تحميل الخدمات' : 'Load Services',
      icon: Package,
      test: () => runTest('services', testLoadServices)
    },
    {
      name: currentLang === 'ar' ? 'إضافة إلى السلة' : 'Add to Cart',
      icon: ShoppingCart,
      test: () => runTest('cart', testAddToCart)
    },
    {
      name: currentLang === 'ar' ? 'إنشاء شكوى' : 'Create Complaint',
      icon: MessageSquare,
      test: () => runTest('complaint', testCreateComplaint)
    },
    {
      name: currentLang === 'ar' ? 'إنشاء باقة' : 'Create Package',
      icon: Package,
      test: () => runTest('packageCreate', testCreatePackage)
    },
    {
      name: currentLang === 'ar' ? 'معالجة الطلب' : 'Process Order',
      icon: CheckCircle,
      test: () => runTest('order', testOrderProcess)
    }
  ];

  const runAllTests = async () => {
    for (const test of allTests) {
      await test.test();
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className={`text-4xl font-bold text-gray-900 mb-4 ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
            {currentLang === 'ar' ? '🧪 صفحة اختبار النظام' : '🧪 System Test Page'}
          </h1>
          <p className={`text-lg text-gray-600 ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
            {currentLang === 'ar' 
              ? 'اختبر جميع ميزات الموقع والتأكد من عملها بشكل صحيح'
              : 'Test all website features and ensure they work correctly'
            }
          </p>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">{currentLang === 'ar' ? 'نظرة عامة' : 'Overview'}</TabsTrigger>
            <TabsTrigger value="tests">{currentLang === 'ar' ? 'الاختبارات' : 'Tests'}</TabsTrigger>
            <TabsTrigger value="data">{currentLang === 'ar' ? 'البيانات' : 'Data'}</TabsTrigger>
            <TabsTrigger value="settings">{currentLang === 'ar' ? 'الإعدادات' : 'Settings'}</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        {currentLang === 'ar' ? 'حالة المستخدم' : 'User Status'}
                      </p>
                      <p className="text-2xl font-bold text-primary">
                        {user ? (currentLang === 'ar' ? 'مسجل' : 'Logged In') : (currentLang === 'ar' ? 'غير مسجل' : 'Not Logged In')}
                      </p>
                    </div>
                    <User className="h-8 w-8 text-primary/60" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        {currentLang === 'ar' ? 'عناصر السلة' : 'Cart Items'}
                      </p>
                      <p className="text-2xl font-bold text-primary">{cart.length}</p>
                    </div>
                    <ShoppingCart className="h-8 w-8 text-primary/60" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        {currentLang === 'ar' ? 'المنتجات' : 'Products'}
                      </p>
                      <p className="text-2xl font-bold text-primary">{services.storeProducts.length}</p>
                    </div>
                    <Store className="h-8 w-8 text-primary/60" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        {currentLang === 'ar' ? 'الاختبارات المكتملة' : 'Tests Completed'}
                      </p>
                      <p className="text-2xl font-bold text-primary">
                        {Object.keys(testResults).length}/{allTests.length}
                      </p>
                    </div>
                    <CheckCircle className="h-8 w-8 text-primary/60" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className={`${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                  {currentLang === 'ar' ? 'معلومات النظام' : 'System Information'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold mb-2">{currentLang === 'ar' ? 'قاعدة البيانات' : 'Database'}</h4>
                    <p className="text-sm text-gray-600">Supabase PostgreSQL</p>
                    <p className="text-sm text-gray-600">
                      {currentLang === 'ar' ? 'الجداول:' : 'Tables:'} 15+ {currentLang === 'ar' ? 'جدول' : 'tables'}
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">{currentLang === 'ar' ? 'المصادقة' : 'Authentication'}</h4>
                    <p className="text-sm text-gray-600">Supabase Auth</p>
                    <p className="text-sm text-gray-600">
                      {currentLang === 'ar' ? 'الأدوار:' : 'Roles:'} Customer, Provider, Admin
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">{currentLang === 'ar' ? 'الخدمات' : 'Services'}</h4>
                    <p className="text-sm text-gray-600">
                      {currentLang === 'ar' ? 'العمرة، الحج، الطيران، الفنادق' : 'Umrah, Hajj, Flights, Hotels'}
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">{currentLang === 'ar' ? 'المتجر' : 'Store'}</h4>
                    <p className="text-sm text-gray-600">
                      {currentLang === 'ar' ? 'منتجات إسلامية ومستلزمات الحج' : 'Islamic products and Hajj supplies'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tests" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className={`text-2xl font-bold ${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                {currentLang === 'ar' ? 'اختبارات النظام' : 'System Tests'}
              </h2>
              <Button onClick={runAllTests} disabled={isLoading}>
                {isLoading ? (
                  <Clock className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <CheckCircle className="mr-2 h-4 w-4" />
                )}
                {currentLang === 'ar' ? 'تشغيل جميع الاختبارات' : 'Run All Tests'}
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {allTests.map((test, index) => (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3 rtl:space-x-reverse">
                        <test.icon className="h-6 w-6 text-primary" />
                        <h3 className="font-semibold">{test.name}</h3>
                      </div>
                      {testResults[test.name.toLowerCase()] && (
                        testResults[test.name.toLowerCase()].success ? (
                          <CheckCircle className="h-5 w-5 text-green-500" />
                        ) : (
                          <XCircle className="h-5 w-5 text-red-500" />
                        )
                      )}
                    </div>
                    
                    {testResults[test.name.toLowerCase()] && (
                      <div className={`p-3 rounded-lg text-sm ${
                        testResults[test.name.toLowerCase()].success 
                          ? 'bg-green-50 text-green-800' 
                          : 'bg-red-50 text-red-800'
                      }`}>
                        {testResults[test.name.toLowerCase()].message}
                      </div>
                    )}
                    
                    <Button 
                      onClick={test.test} 
                      disabled={isLoading}
                      className="w-full mt-4"
                      variant="outline"
                    >
                      {currentLang === 'ar' ? 'تشغيل الاختبار' : 'Run Test'}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="data" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className={`${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                    {currentLang === 'ar' ? 'منتجات المتجر' : 'Store Products'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {services.storeProducts.map((product) => (
                      <div key={product.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-semibold">{product.name}</p>
                          <p className="text-sm text-gray-600">{product.category}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-primary">{product.price} {currentLang === 'ar' ? 'ريال' : 'SAR'}</p>
                          <p className="text-sm text-gray-600">
                            {currentLang === 'ar' ? 'الكمية:' : 'Stock:'} {product.stock_quantity}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className={`${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                    {currentLang === 'ar' ? 'باقات العمرة' : 'Umrah Packages'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {services.umrahPackages.map((pkg) => (
                      <div key={pkg.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-semibold">{pkg.title}</p>
                          <p className="text-sm text-gray-600">{pkg.city}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-primary">{pkg.price} {currentLang === 'ar' ? 'ريال' : 'SAR'}</p>
                          <p className="text-sm text-gray-600">{pkg.duration_days} {currentLang === 'ar' ? 'أيام' : 'days'}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className={`${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                  {currentLang === 'ar' ? 'محتويات السلة' : 'Cart Contents'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {cart.length > 0 ? (
                  <div className="space-y-3">
                    {cart.map((item) => (
                      <div key={item.cartId} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-semibold">{item.name || item.title}</p>
                          <p className="text-sm text-gray-600">{item.type}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-primary">{item.price} {currentLang === 'ar' ? 'ريال' : 'SAR'}</p>
                          <p className="text-sm text-gray-600">
                            {currentLang === 'ar' ? 'الكمية:' : 'Qty:'} {item.quantity}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-gray-500 py-8">
                    {currentLang === 'ar' ? 'السلة فارغة' : 'Cart is empty'}
                  </p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className={`${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                    {currentLang === 'ar' ? 'بيانات الاختبار' : 'Test Data'}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="testEmail">{currentLang === 'ar' ? 'البريد الإلكتروني' : 'Email'}</Label>
                    <Input
                      id="testEmail"
                      value={testData.email}
                      onChange={(e) => setTestData({...testData, email: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="testPassword">{currentLang === 'ar' ? 'كلمة المرور' : 'Password'}</Label>
                    <Input
                      id="testPassword"
                      type="password"
                      value={testData.password}
                      onChange={(e) => setTestData({...testData, password: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="testName">{currentLang === 'ar' ? 'الاسم الكامل' : 'Full Name'}</Label>
                    <Input
                      id="testName"
                      value={testData.fullName}
                      onChange={(e) => setTestData({...testData, fullName: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="testRole">{currentLang === 'ar' ? 'الدور' : 'Role'}</Label>
                    <Select value={testData.role} onValueChange={(value) => setTestData({...testData, role: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="customer">{currentLang === 'ar' ? 'عميل' : 'Customer'}</SelectItem>
                        <SelectItem value="service_provider">{currentLang === 'ar' ? 'مقدم خدمة' : 'Service Provider'}</SelectItem>
                        <SelectItem value="super_admin">{currentLang === 'ar' ? 'مدير عام' : 'Super Admin'}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className={`${currentLang === 'ar' ? 'font-arabic' : 'font-english'}`}>
                    {currentLang === 'ar' ? 'إجراءات سريعة' : 'Quick Actions'}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {user ? (
                    <Button onClick={logout} variant="outline" className="w-full">
                      {currentLang === 'ar' ? 'تسجيل الخروج' : 'Logout'}
                    </Button>
                  ) : (
                    <>
                      <Button onClick={() => runTest('registration', testUserRegistration)} className="w-full">
                        {currentLang === 'ar' ? 'تسجيل مستخدم جديد' : 'Register New User'}
                      </Button>
                      <Button onClick={() => runTest('login', testUserLogin)} variant="outline" className="w-full">
                        {currentLang === 'ar' ? 'تسجيل الدخول' : 'Login'}
                      </Button>
                    </>
                  )}
                  
                  <Button onClick={() => runTest('services', testLoadServices)} variant="outline" className="w-full">
                    {currentLang === 'ar' ? 'تحديث الخدمات' : 'Refresh Services'}
                  </Button>
                  
                  <Button onClick={() => runTest('cart', testAddToCart)} variant="outline" className="w-full">
                    {currentLang === 'ar' ? 'إضافة منتج للسلة' : 'Add Product to Cart'}
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default TestPage;